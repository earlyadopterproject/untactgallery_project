import React from 'react';

const ArtistPage = () => {
    return (
        <div>
            작가페이지
            
        </div>
    );
};

export default ArtistPage;