import React from 'react';
import SocialLogin from "../components/login/SocialLogin";
import LoginPage from "../components/login/LoginPage";

const LoginDetail = () => {
    return (
        <div>
            <SocialLogin/>
            <LoginPage/>
        </div>
    );
};

export default LoginDetail;