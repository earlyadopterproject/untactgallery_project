import React from 'react';
import styled from "styled-components";
import Signup from '../components/login/Signup'

const Container = styled.div`

`;

const SignUpDetail = () => {
    return (
        <Container>
            <Signup/>
        </Container>
    );
};

export default SignUpDetail;