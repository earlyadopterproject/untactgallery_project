import React from "react";
import ArtistPage from "../components/artist/ArtistPage";

const ArtistDetail = () => {
    return <div>
      <ArtistPage/>
    </div>;
};

export default ArtistDetail;
