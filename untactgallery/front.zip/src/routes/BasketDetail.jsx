import React from 'react';
import BusketList from "../components/basket/BusketList";

const BasketDetail = () => {
    return (
        <div>
            <BusketList/>
        </div>
    );
};

export default BasketDetail;